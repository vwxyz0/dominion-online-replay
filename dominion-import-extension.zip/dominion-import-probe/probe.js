(function (root) {
  "use strict";

  const VERSION = "0.2.3";
  const BUTTON_ID = "dominion-import-probe-button";
  const record = typeof window === "undefined" && typeof module === "object" && module.exports ?
    require("./record.js") : root.DominionRecordExport;
  const pair = typeof window === "undefined" && typeof module === "object" && module.exports ?
    require("./pair.js") : root.DominionRecordPair;

  function gameNumber(value) {
    const text = String(value == null ? "" : value).trim();
    if (!/^[1-9][0-9]{0,15}$/.test(text)) return null;
    const number = Number(text);
    return Number.isSafeInteger(number) ? String(number) : null;
  }

  function isVisible(element, env) {
    if (!element || !element.isConnected) return false;
    const box = element.getBoundingClientRect();
    if (!(box.width > 0 && box.height > 0)) return false;
    for (let node = element; node && node.nodeType === 1; node = node.parentElement) {
      const style = env.getComputedStyle(node);
      if (node.hidden || style.display === "none" || style.visibility === "hidden" ||
          style.visibility === "collapse" || Number(style.opacity) === 0) return false;
    }
    return true;
  }

  function booleanCall(object, name) {
    try {
      if (!object || typeof object[name] !== "function") return null;
      const result = object[name]();
      return typeof result === "boolean" ? result : null;
    } catch (_) {
      return null;
    }
  }

  function ruleBoolean(table, ruleId) {
    try {
      if (!table || !ruleId || typeof table.getRule !== "function") return null;
      const rule = table.getRule(ruleId);
      return rule && typeof rule.value === "boolean" ? rule.value : null;
    } catch (_) {
      return null;
    }
  }

  function findInjector(env) {
    try {
      const angular = env.angular;
      if (!angular || typeof angular.element !== "function") return null;
      const candidates = [env.document.body, env.document.documentElement,
        env.document.querySelector("[ng-app], [data-ng-app]")];
      for (const node of candidates) {
        if (!node) continue;
        const wrapped = angular.element(node);
        if (wrapped && typeof wrapped.injector === "function") {
          const injector = wrapped.injector();
          if (injector && typeof injector.get === "function") return injector;
        }
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  function service(injector, name) {
    try {
      return injector && injector.get(name);
    } catch (_) {
      return null;
    }
  }

  function readContext(env) {
    const context = {
      officialSite: env.location.protocol === "https:" && env.location.hostname === "dominion.games",
      panelVisible: false,
      inputVisible: false,
      gameRunning: null,
      hasTable: null,
      host: null,
      startingGame: null,
      rated: null,
      tournament: null,
      requestedGameId: null,
      panel: null,
      game: null,
      replay: null,
      injectorAvailable: false
    };
    if (!context.officialSite) return context;
    const panel = env.document.querySelector(".table-replay-buttons");
    const input = env.document.getElementById("table-replay-id");
    context.panelVisible = isVisible(panel, env);
    context.inputVisible = isVisible(input, env);
    if (!context.panelVisible || !context.inputVisible) return context;
    context.panel = panel;
    context.requestedGameId = gameNumber(input.value);
    const injector = findInjector(env);
    context.injectorAvailable = Boolean(injector);
    if (!injector) return context;
    const game = service(injector, "game");
    context.gameRunning = booleanCall(game, "isRunning");
    if (context.gameRunning !== false) return context;
    const tableService = service(injector, "tableService");
    context.hasTable = booleanCall(tableService, "hasTable");
    context.host = booleanCall(tableService, "heroIsHost");
    context.startingGame = booleanCall(tableService, "isStartingGame");
    if (context.hasTable !== true) return context;
    let table;
    try {
      table = tableService.getTable();
    } catch (_) {
      return context;
    }
    const ruleIds = env.TableRuleIds || {};
    context.rated = ruleBoolean(table, ruleIds.RATED_GAME);
    context.tournament = ruleBoolean(table, ruleIds.TOURNAMENT_MODE);
    context.game = game;
    context.replay = service(injector, "replayService");
    return context;
  }

  function gate(context) {
    if (!context.officialSite || !context.panelVisible || !context.inputVisible) return "hidden";
    if (context.gameRunning === true || context.startingGame === true ||
        context.rated === true || context.tournament === true || context.host === false) return "hidden";
    if (context.gameRunning !== false || context.hasTable !== true || context.host !== true ||
        context.startingGame !== false || context.rated !== false || context.tournament !== false ||
        !context.injectorAvailable) return "unavailable";
    if (!context.requestedGameId) return "number-needed";
    return "ready";
  }

  function clientVersion(env) {
    for (const script of env.document.scripts || []) {
      const match = String(script.src || "").match(/\/dominion-webclient-body-([0-9.]+)\.min\.js(?:[?#]|$)/);
      if (match) return match[1];
    }
    return null;
  }

  function makeReport(context, env) {
    if (gate(context) !== "ready") return null;
    if (booleanCall(context.game, "isRunning") !== false) return null;
    const game = context.game;
    const replay = context.replay;
    const logModel = game && game.logModel;
    const completedGameRetained = Boolean(game && game.metaGameModel && game.metaGameModel.gameResult != null);
    // Only inspect entry shape after an inactive, completed game. Never export values.
    let entryCount = null;
    let structuredEntries = null;
    let decisionEntries = null;
    if (completedGameRetained && logModel && Array.isArray(logModel.entries)) {
      entryCount = logModel.entries.length;
      structuredEntries = 0;
      decisionEntries = 0;
      for (const entry of logModel.entries) {
        if (entry && Array.isArray(entry.logArguments)) structuredEntries += 1;
        if (entry && Number.isInteger(entry.decisionIndex)) decisionEntries += 1;
      }
    }
    return {
      format: "dominion-import-check/v1",
      probeVersion: VERSION,
      createdAt: new Date().toISOString(),
      clientVersion: clientVersion(env),
      requestedGameId: context.requestedGameId,
      checks: {
        pastGameLoadingPanelVisible: true,
        currentGameRunning: false,
        tableHost: true,
        ratedTable: false,
        tournamentTable: false,
        startingGame: false,
        replayServiceAvailable: Boolean(replay),
        replayInstructionsAccessorAvailable: Boolean(replay && typeof replay.getReplayInstructions === "function"),
        logModelAvailable: Boolean(logModel),
        logEntryArrayAvailable: Boolean(logModel && Array.isArray(logModel.entries)),
        logUpdateMethodAvailable: Boolean(logModel && typeof logModel.newLogEntries === "function"),
        cardNameCatalogAvailable: Boolean(env.CardNames && typeof env.CardNames === "object"),
        logEntryNameCatalogAvailable: Boolean(env.LogEntryNames && typeof env.LogEntryNames === "object"),
        logArgumentParserCatalogAvailable: Boolean(env.LogArgumentParsers && typeof env.LogArgumentParsers === "object"),
        completedGameRetained: completedGameRetained
      },
      completedLogShape: {
        entryCount,
        entriesWithStructuredArguments: structuredEntries,
        decisionEntries
      },
      scope: {
        kind: "availability-check",
        noGameplayRequests: true,
        noAutomaticGameLoading: true,
        noGameCardValuesExported: true,
        retainedCompletedLogIsNotYetVerifiedAgainstRequestedId: true
      }
    };
  }

  function exportStatus(context) {
    const state = gate(context);
    if (state !== "ready") return state;
    if (booleanCall(context.game, "isRunning") !== false) return "hidden";
    try {
      if (!context.game.metaGameModel || context.game.metaGameModel.gameResult == null) return "completed-game-needed";
      const log = context.game.logModel;
      if (!log || !Array.isArray(log.entries) || log.entries.length === 0) return "completed-log-needed";
      return "ready";
    } catch (_) { return "unavailable"; }
  }

  function makeRecord(context, env) {
    const current = readContext(env);
    if (exportStatus(current) !== "ready" || current.game !== context.game || current.requestedGameId !== context.requestedGameId) return null;
    return record.build(current, env, clientVersion(env));
  }

  function downloadReport(report, env) {
    const text = JSON.stringify(report, null, 2) + "\n";
    const url = env.URL.createObjectURL(new env.Blob([text], { type: "application/json;charset=utf-8" }));
    const anchor = env.document.createElement("a");
    anchor.href = url;
    const stamp = report.createdAt.replace(/[^0-9]/g, "").slice(0, 14);
    const actualRecord = report.format === "dominion-replay-record/v1";
    const actualPair = report.format === "dominion-replay-pair/v1";
    const number = actualRecord ? (report.source.retainedLogGameIds[0] || report.source.resultGameId || report.source.requestedArchiveId) :
      actualPair ? report.requestedArchiveId : report.requestedGameId;
    anchor.download = (actualRecord ? "dominion-replay-record-" : actualPair ? "dominion-replay-pair-" : "dominion-import-check-") + number + "-" + stamp + ".json";
    anchor.hidden = true;
    env.document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    env.setTimeout(function () { env.URL.revokeObjectURL(url); }, 1000);
  }

  function legacyCopy(text, env) {
    if (typeof env.document.execCommand !== "function") return false;
    const previous = env.document.activeElement;
    const start = previous && previous.selectionStart;
    const end = previous && previous.selectionEnd;
    const direction = previous && previous.selectionDirection;
    const area = env.document.createElement("textarea");
    area.value = text;
    area.readOnly = true;
    area.setAttribute("aria-hidden", "true");
    area.style.position = "fixed";
    area.style.left = "-10000px";
    area.style.top = "0";
    env.document.body.appendChild(area);
    try {
      area.focus({ preventScroll: true });
      area.select();
      return env.document.execCommand("copy") === true;
    } catch (_) { return false; }
    finally {
      area.remove();
      try {
        if (previous && previous.isConnected && typeof previous.focus === "function") {
          previous.focus({ preventScroll: true });
          if (typeof start === "number" && typeof end === "number" && typeof previous.setSelectionRange === "function") {
            previous.setSelectionRange(start, end, direction);
          }
        }
      } catch (_) { /* A removed or changed input must not interfere with export. */ }
    }
  }

  function copyText(text, env, finished, canFallback) {
    // Invoked directly from a click; writes only, and never reads the clipboard.
    function fallback() {
      if (canFallback && !canFallback()) { finished(null); return; }
      let copied = false;
      try { copied = legacyCopy(text, env); } catch (_) { /* Retain the file fallback. */ }
      finished(copied);
    }
    try {
      if (env.navigator && env.navigator.clipboard && typeof env.navigator.clipboard.writeText === "function") {
        Promise.resolve(env.navigator.clipboard.writeText(text)).then(function () { finished(true); }, fallback);
      } else fallback();
    } catch (_) { fallback(); }
  }

  function mount(env) {
    if (!env.document || env.location.protocol !== "https:" || env.location.hostname !== "dominion.games") return;
    let button = null;
    let feedback = null;
    let feedbackUntil = 0;
    let busy = false;
    let disposed = false;
    const buffer = pair.createBuffer();
    function removeButton() {
      if (button) button.remove();
      button = null;
    }
    function refresh() {
      const context = readContext(env);
      const state = exportStatus(context);
      if (state === "hidden") {
        removeButton();
        return;
      }
      if (!button || !button.isConnected || button.parentElement !== context.panel) {
        removeButton();
        const previous = env.document.getElementById(BUTTON_ID);
        if (previous) previous.remove();
        button = env.document.createElement("button");
        button.id = BUTTON_ID;
        button.type = "button";
        button.className = "oval-button unselectable";
        button.textContent = "棋譜をコピー";
        button.style.padding = "0.45em 0.9em";
        button.style.margin = "0.2em";
        function exportClicked(asFile) {
          if (busy || disposed) return;
          const current = readContext(env);
          if (exportStatus(current) !== "ready") {
            refresh();
            return;
          }
          try {
            const exported = makeRecord(current, env);
            if (!exported) { refresh(); return; }
            const bundled = buffer.add(exported);
            const payload = bundled.payload;
            if (asFile) {
              downloadReport(payload, env);
              feedback = bundled.paired ? "両視点をファイルに保存" : "ファイルに保存しました";
              feedbackUntil = Date.now() + 5000;
              refresh();
            } else {
              const compact = JSON.stringify(payload);
              busy = true;
              refresh();
              copyText(compact, env, function (copied) {
                busy = false;
                if (disposed) return;
                if (copied === null) { refresh(); return; }
                if (!copied) downloadReport(payload, env);
                feedback = copied ? (bundled.paired ? "両視点をコピーしました（Ctrl+V）" : "コピーしました（Ctrl+V）") : "コピー不可：ファイルに保存";
                feedbackUntil = Date.now() + 7000;
                refresh();
              }, function () { return !disposed && exportStatus(readContext(env)) === "ready"; });
            }
          } catch (_) {
            const report = makeReport(readContext(env), env);
            if (report) {
              report.exportIssue = "record-format-not-supported";
              downloadReport(report, env);
              if (typeof env.alert === "function") env.alert("棋譜の形式を確認できなかったため、確認用ファイルを保存しました。このファイルを会話に添付してください。");
            }
          }
        }
        button.addEventListener("click", function (event) { exportClicked(Boolean(event && event.shiftKey)); });
        button.addEventListener("contextmenu", function (event) {
          event.preventDefault();
          exportClicked(true);
        });
        context.panel.appendChild(button);
      }
      const disabled = state !== "ready" || busy;
      const label = busy ? "コピー中…" : feedback && Date.now() < feedbackUntil ? feedback : "棋譜をコピー";
      if (button.textContent !== label) button.textContent = label;
      if (button.disabled !== disabled) button.disabled = disabled;
      const opacity = disabled ? "0.5" : "1";
      if (button.style.opacity !== opacity) button.style.opacity = opacity;
      const title = state === "ready" ? "左クリックで棋譜をコピー。反対側の席も同じタブで取得すると両視点をまとめます。右クリックまたはShift-clickでファイル保存。ページ再読み込みで保持を解除（0.2.3）" :
        state === "number-needed" ? "ゲーム番号を入力してください" :
        state === "completed-game-needed" || state === "completed-log-needed" ?
          "公式の「終局から読み込む」で読み込み、終了画面を閉じて「卓の編集」で戻ってください。ページは再読み込みしないでください。" :
          "公式画面の状態を確認できないため、書き出しを無効にしています";
      if (button.title !== title) button.title = title;
    }
    env.document.addEventListener("input", refresh);
    // This only checks the loading screen and eligibility, not card or log values.
    const interval = env.setInterval(refresh, 750);
    env.addEventListener("pagehide", function () {
      disposed = true;
      buffer.clear();
      env.clearInterval(interval);
      env.document.removeEventListener("input", refresh);
      removeButton();
    }, { once: true });
    refresh();
    return { refresh, removeButton };
  }

  const api = { gameNumber, isVisible, readContext, gate, makeReport, exportStatus, makeRecord, downloadReport, copyText, mount };
  if (typeof window === "undefined" && typeof module === "object" && module.exports) module.exports = api;
  else mount(root);
})(typeof globalThis === "object" ? globalThis : this);
