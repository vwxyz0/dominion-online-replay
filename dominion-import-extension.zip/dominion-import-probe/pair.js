(function (root) {
  "use strict";
  // Offline only. Pair logs by operation order, keeping decisions and board states separate.
  const TYPES = ["CARD_NAMES", "PLAYER", "ZONE", "OWN_ZONE", "NUMBER", "COUNTER",
    "TURN_DESCRIPTION", "AMOUNT", "ABILITY_DESCRIPTION", "EVENT", "CARD", "SINGULAR_CARD",
    "TOKEN", "DIRECTIONAL_ZONE", "PLAYERS", "METAGAME_INFO"];
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function same(a, b) {
    if (a === b) return true;
    if (!a || !b || typeof a !== "object" || typeof b !== "object" || Array.isArray(a) !== Array.isArray(b)) return false;
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every(key => Object.hasOwn(b, key) && same(a[key], b[key]));
  }
  function frequency(value) {
    if (!Array.isArray(value)) throw new Error("invalid-card-frequencies");
    const known = new Map();
    let hidden = 0;
    let total = 0;
    for (const item of value) {
      if (!item || typeof item.card !== "string" || !/^[A-Z][A-Z0-9_]*$/.test(item.card) ||
          !Number.isSafeInteger(item.count) || item.count < 1) throw new Error("invalid-card-frequency");
      total += item.count;
      if (!Number.isSafeInteger(total)) throw new Error("invalid-card-count");
      if (item.card === "BACK") hidden += item.count;
      else known.set(item.card, (known.get(item.card) || 0) + item.count);
    }
    return { known, hidden, total };
  }
  function mergeCards(a, b) {
    const first = frequency(a), second = frequency(b);
    if (first.total !== second.total) throw new Error("card-count-conflict");
    // Counts are lower bounds when a view also has BACK. Never add duplicate observations.
    const known = new Map(first.known);
    for (const [card, count] of second.known) known.set(card, Math.max(count, known.get(card) || 0));
    const knownTotal = Array.from(known.values()).reduce((sum, count) => sum + count, 0);
    if (knownTotal > first.total) throw new Error("known-card-conflict");
    const merged = Array.from(known, ([card, count]) => ({ card, count }));
    if (knownTotal < first.total) merged.push({ card: "BACK", count: first.total - knownTotal });
    return merged;
  }
  function mergeArgument(a, b, entryName, depth) {
    if (depth > 24 || !a || !b || !TYPES.includes(a.type) || a.type !== b.type ||
        a.typeIndex !== TYPES.indexOf(a.type) || b.typeIndex !== a.typeIndex) throw new Error("argument-type-conflict");
    let value;
    if (a.type === "CARD_NAMES") value = mergeCards(a.value, b.value);
    else if (a.type === "SINGULAR_CARD") {
      if (typeof a.value !== "string" || typeof b.value !== "string") throw new Error("unavailable-card");
      if (a.value !== b.value && a.value !== "BACK" && b.value !== "BACK") throw new Error("known-card-conflict");
      value = a.value === "BACK" ? b.value : a.value;
    } else if (a.type === "METAGAME_INFO" && entryName === "GAME_META_INFO") {
      const first = clone(a.value), second = clone(b.value);
      delete first.gameId;
      delete second.gameId;
      if (!same(first, second)) throw new Error("game-metadata-conflict");
      // A copied game id is not an original game id. Preserve both in provenance.
      value = { ...first, gameId: null };
    } else if (a.type === "ABILITY_DESCRIPTION" || a.type === "EVENT") {
      value = mergeNested(a.value, b.value, entryName, depth + 1);
    } else {
      if (!same(a.value, b.value) || (a.value && a.value.unavailable)) throw new Error("argument-value-conflict");
      value = clone(a.value);
    }
    return { type: a.type, typeIndex: a.typeIndex, value };
  }
  function mergeNested(a, b, entryName, depth) {
    if (depth > 24 || !a || !b || typeof a !== "object" || typeof b !== "object" || a.unavailable || b.unavailable) {
      throw new Error("unavailable-nested-argument");
    }
    const keys = Object.keys(a);
    if (!same(keys.slice().sort(), Object.keys(b).sort())) throw new Error("nested-shape-conflict");
    const merged = Object.create(null);
    for (const key of keys) {
      if (key === "arguments") merged[key] = mergeArguments(a[key], b[key], entryName, depth + 1);
      else if (key === "description") merged[key] = mergeNested(a[key], b[key], entryName, depth + 1);
      else {
        if (!same(a[key], b[key])) throw new Error("nested-value-conflict");
        merged[key] = clone(a[key]);
      }
    }
    return merged;
  }
  function mergeArguments(a, b, entryName, depth) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) throw new Error("argument-shape-conflict");
    return a.map((arg, index) => mergeArgument(arg, b[index], entryName, depth || 0));
  }
  function validate(record) {
    if (!record || record.format !== "dominion-replay-record/v1" || !Array.isArray(record.entries) ||
        !record.entries.length || record.entries.length > 100000 ||
        !record.entries.every((entry, index) => entry && entry.index === index && ["log", "decision"].includes(entry.kind))) {
      throw new Error("incomplete-or-unsupported-record");
    }
    if (!record.source || !record.finalState || !Array.isArray(record.finalState.players) ||
        record.finalState.players.length < 2 || record.finalState.players.length > 6 ||
        !record.finalState.players.every((player, index) => player && player.index === index)) throw new Error("missing-source-or-players");
  }
  function hiddenMentions(value) {
    if (!value || typeof value !== "object") return 0;
    if (value.type === "CARD_NAMES") return frequency(value.value).hidden;
    if (value.type === "SINGULAR_CARD") return value.value === "BACK" ? 1 : 0;
    return Object.values(value).reduce((sum, child) => sum + hiddenMentions(child), 0);
  }
  function build(first, second) {
    validate(first); validate(second);
    const source = first.source, other = second.source;
    const rosterCompared=Array.isArray(source.replaySettingPlayers)&&source.replaySettingPlayers.length>0&&
      Array.isArray(other.replaySettingPlayers)&&other.replaySettingPlayers.length>0;
    if (first.finalState.players.length !== second.finalState.players.length ||
        !source.requestedArchiveId || source.requestedArchiveId !== other.requestedArchiveId ||
        source.replayRuleArchiveId !== source.requestedArchiveId || other.replayRuleArchiveId !== other.requestedArchiveId ||
        source.replayDecisionIndex !== other.replayDecisionIndex ||
        (rosterCompared&&!same(source.replaySettingPlayers, other.replaySettingPlayers))) throw new Error("archive-setting-conflict");
    const firstSeats = first.finalState.players.filter(player => player.isMe === true).map(player => player.index);
    const secondSeats = second.finalState.players.filter(player => player.isMe === true).map(player => player.index);
    if (firstSeats.length !== 1 || secondSeats.length !== 1 || firstSeats[0] === secondSeats[0]) throw new Error("opposite-view-needed");
    const a = first.entries.filter(entry => entry.kind === "log"), b = second.entries.filter(entry => entry.kind === "log");
    const commonLogs = [];
    let conflict = null;
    for (let i = 0; i < Math.min(a.length, b.length); i += 1) {
      try {
        if (!a[i].name || a[i].name !== b[i].name || a[i].depth !== b[i].depth) throw new Error("operation-conflict");
        const args = mergeArguments(a[i].arguments, b[i].arguments, a[i].name, 0);
        commonLogs.push({ kind: "log", ordinal: i, name: a[i].name, depth: a[i].depth, arguments: args,
          sourceIndexes: [a[i].index, b[i].index],
          sourceTextLines: [clone(a[i].textLines), clone(b[i].textLines)] });
      } catch (error) {
        conflict = { logOrdinal: i, reason: error.message,
          first: { index: a[i].index, name: a[i].name }, second: { index: b[i].index, name: b[i].name } };
        break;
      }
    }
    if (!conflict && a.length !== b.length) conflict = { logOrdinal: commonLogs.length, reason: "log-length-conflict",
      first: a[commonLogs.length] ? { index: a[commonLogs.length].index, name: a[commonLogs.length].name } : null,
      second: b[commonLogs.length] ? { index: b[commonLogs.length].index, name: b[commonLogs.length].name } : null };
    if (commonLogs.length < 2) throw new Error("no-matching-gameplay-prefix");
    const before = a.slice(0, commonLogs.length).reduce((sum, entry) => sum + hiddenMentions(entry.arguments), 0);
    const after = commonLogs.reduce((sum, entry) => sum + hiddenMentions(entry.arguments), 0);
    return { format: "dominion-replay-pair/v1", createdAt: new Date().toISOString(),
      requestedArchiveId: source.requestedArchiveId,
      provenance: { views: [firstSeats[0], secondSeats[0]],
        copyGameIds: [clone(source.retainedLogGameIds), clone(other.retainedLogGameIds)],
        compatibility: "matching-settings-and-common-operation-prefix", originalRosterCompared:rosterCompared,archiveOriginVerified: false },
      summary: { commonLogCount: commonLogs.length, allLogsMatch: !conflict,
        lastSourceIndexes: commonLogs[commonLogs.length - 1].sourceIndexes,
        hiddenMentionsInFirstView: before, hiddenMentionsAfterPairing: after,
        knownCardMentionsAdded: before - after, perViewTailLogCounts: [a.length - commonLogs.length, b.length - commonLogs.length] },
      commonLogs, conflict,
      // Do not combine private decision vectors, final states, results or divergent suffixes.
      records: [clone(first), clone(second)],
      warnings: [{ code: "archive-origin-not-verified" }, ...(conflict ? [{ code: "divergent-tails-kept-separate" }] : [])],
      scope: { kind: "paired-log-prefix", clientVisibleDataOnly: true, omniscient: false,
        containsHistoricalBoardSnapshots: false, deckOrderReconstructed: false, requiresReplayAdapter: true } };
  }
  function createBuffer() {
    let key = null;
    const views = new Map();
    function clear() { key = null; views.clear(); }
    function add(record) {
      const s = record && record.source;
      const players = record && record.finalState && record.finalState.players;
      const mine = Array.isArray(players) ? players.filter(p => p && p.isMe === true) : null;
      if (!s || !s.requestedArchiveId||s.requestedArchiveId !== s.replayRuleArchiveId ||
          !mine || mine.length !== 1 || !Number.isSafeInteger(mine[0].index)) {
        clear(); return { payload: record, paired: false };
      }
      const currentKey = JSON.stringify([s.requestedArchiveId, s.replayRuleArchiveId, s.replayDecisionIndex]);
      if (currentKey !== key) { clear(); key = currentKey; }
      views.set(mine[0].index, clone(record));
      if (views.size > 2) views.delete(views.keys().next().value);
      if (views.size !== 2) return { payload: record, paired: false };
      const sorted = Array.from(views).sort((a, b) => a[0] - b[0]);
      try { return { payload: build(sorted[0][1], sorted[1][1]), paired: true }; }
      catch (_) {
        clear(); key = currentKey; views.set(mine[0].index, clone(record));
        return { payload: record, paired: false };
      }
    }
    return { add, clear };
  }
  const api = { build, mergeCards, createBuffer };
  if (typeof window === "undefined" && typeof module === "object" && module.exports) module.exports = api;
  else root.DominionRecordPair = api;
})(typeof globalThis === "object" ? globalThis : this);
