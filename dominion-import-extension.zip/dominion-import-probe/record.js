(function (root) {
  "use strict";
  // Only whitelisted completed-game fields, never the cyclic game/service graph.
  const VERSION = "0.2.3";
  const ARGUMENT_TYPES = ["CARD_NAMES", "PLAYER", "ZONE", "OWN_ZONE", "NUMBER",
    "COUNTER", "TURN_DESCRIPTION", "AMOUNT", "ABILITY_DESCRIPTION", "EVENT",
    "CARD", "SINGULAR_CARD", "TOKEN", "DIRECTIONAL_ZONE", "PLAYERS", "METAGAME_INFO"];
  const ZONE_CLASSES = ["HandZone", "DrawZone", "DiscardZone", "TrashZone",
    "SupplyCardZone", "BasicTreasureZone", "BasicVictoryZone", "SingleLandscapeZone",
    "InPlayZone", "HiddenWindowZone", "TavernZone", "NVZone", "IslandZone",
    "NonSupplyZone", "DruidBoonZone", "ExileZone", "MouseZone", "RevealZone",
    "SetAsideZone", "SkippableRevealZone", "TheBox", "InteractiveNonSupplyZone", "ReducedLandscapeZone"];

  function id(value) {
    const v = typeof value === "number" || typeof value === "string" ? String(value) : "";
    return /^[1-9][0-9]{0,15}$/.test(v) && Number.isSafeInteger(Number(v)) ? v : null;
  }
  function integer(value) {
    if (!Number.isSafeInteger(value)) throw new Error("invalid-integer");
    return value;
  }
  function bool(value) {
    if (typeof value !== "boolean") throw new Error("invalid-boolean");
    return value;
  }
  function list(value) {
    if (!Array.isArray(value) || value.length > 100000) throw new Error("invalid-array");
    return value;
  }
  function text(value, maximum) { return typeof value === "string" ? value.slice(0, maximum) : null; }

  function serializer(env) {
    const maps = new Map();
    const referencedCards = new Set();
    const warnings = [];
    const warningKeys = new Set();
    const ancestry = new Set();
    let nodes = 0;
    function warn(code, where) {
      const key = code + ":" + where;
      if (warningKeys.has(key)) return;
      warningKeys.add(key);
      if (warnings.length < 1000) warnings.push({ code, where });
    }
    function attempt(where, callback) {
      try { return callback(); }
      catch (_) { warn("unsupported-record-shape", where); return { unavailable: true }; }
    }
    function enumKey(catalog, value, where, optional) {
      if (value == null && optional) return null;
      if (!maps.has(catalog)) {
        const map = new Map();
        for (const [key, object] of Object.entries(env[catalog] || {})) if (!map.has(object)) map.set(object, key);
        maps.set(catalog, map);
      }
      const key = maps.get(catalog).get(value);
      if (key === undefined) { warn("unknown-enum-" + catalog, where); return null; }
      if (catalog === "CardNames") referencedCards.add(key);
      return key;
    }
    function nested(value, where, depth, callback) {
      if (++nodes > 200000 || depth > 24 || !value || typeof value !== "object" || ancestry.has(value)) throw new Error("invalid-nesting");
      ancestry.add(value);
      try { return callback(); } finally { ancestry.delete(value); }
    }
    function cost(value) {
      return { coin: integer(value.coin), potion: integer(value.potion), debt: integer(value.debt), isSpecial: bool(value.isSpecial) };
    }
    function frequencies(value, where) {
      return list(value).map(function (card, i) {
        return { card: enumKey("CardNames", card.cardName, where + "/" + i), count: integer(card.frequency) };
      });
    }
    function turn(value) {
      return { ownerId: integer(value.ownerId), turnNumber: integer(value.turnNumber),
        turnType: integer(value.turnType), controllerId: integer(value.controllerId) };
    }
    function ability(value, where, depth) {
      return nested(value, where, depth, function () {
        const catalog = Object.values(env.AbilityNames || {}).includes(value.name) ? "AbilityNames" : "MovementTypes";
        return { name: enumKey(catalog, value.name, where + "/name"), nameCatalog: catalog,
          association: integer(value.association), isOptional: bool(value.isOptional),
          copyIndex: integer(value.copyIndex), copyTotal: integer(value.copyTotal),
          arguments: argumentsList(value.logEntryArguments, where + "/arguments", depth + 1) };
      });
    }
    function argument(value, where, depth) {
      return nested(value, where, depth, function () {
        const typeIndex = integer(value.type);
        const type = Object.keys(env.LogArgumentParsers || {})[typeIndex];
        const v = value.argument;
        let result;
        switch (type) {
          case "CARD_NAMES": result = frequencies(v, where); break;
          case "PLAYER": case "ZONE": case "NUMBER": case "COUNTER": case "CARD": case "TOKEN": result = integer(v); break;
          case "OWN_ZONE": result = { playerIndex: integer(v.playerIndex), zoneIndex: integer(v.zoneIndex) }; break;
          case "TURN_DESCRIPTION": result = turn(v); break;
          case "AMOUNT": result = cost(v); break;
          case "ABILITY_DESCRIPTION": result = ability(v, where, depth + 1); break;
          case "EVENT": result = nested(v, where, depth + 1, function () {
            return { type: enumKey("EventTypes", v.type, where + "/eventType"),
              description: ability(v.description, where + "/description", depth + 2),
              arguments: argumentsList(v.logEntryArguments, where + "/arguments", depth + 2) };
          }); break;
          case "SINGULAR_CARD": result = enumKey("CardNames", v, where); break;
          case "DIRECTIONAL_ZONE": result = { index: integer(v.index), direction: enumKey("Directions", v.direction, where + "/direction") }; break;
          case "PLAYERS": result = list(v).map(integer); break;
          case "METAGAME_INFO": result = { gameId: id(v.gameId), isRated: bool(v.isRated), cardPoolLevel: integer(v.cardPoolLevel),
            timerPreset: enumKey("TimerPresetOptions", v.timerPresetOption, where + "/timerPreset", true) }; break;
          default: warn("unknown-argument-type", where); result = { unavailable: true };
        }
        return { type: type || null, typeIndex, value: result };
      });
    }
    function argumentsList(value, where, depth) {
      return list(value).map(function (v, i) { return attempt(where + "/" + i, function () { return argument(v, where + "/" + i, depth); }); });
    }
    function logEntry(entry, where, depth) {
      return nested(entry, where, depth || 0, function () {
        const lines = Array.isArray(entry.renderedLines) ? entry.renderedLines.map(function (line) {
          return text(line && line.textContent, 100000);
        }).filter(function (line) { return line !== null; }) : [];
        return { kind: "log", index: integer(entry.index), depth: integer(entry.depth),
          name: enumKey("LogEntryNames", entry.name, where + "/name"),
          arguments: argumentsList(entry.logArguments, where + "/arguments", (depth || 0) + 1), textLines: lines };
      });
    }
    function entry(value, where) {
      return attempt(where, function () {
        if (Array.isArray(value.logArguments)) return logEntry(value, where, 0);
        return { kind: "decision", index: integer(value.index), decisionIndex: integer(value.decisionIndex),
          playerIndex: integer(value.playerIndex), decision: list(value.decision).map(integer), autoPlayed: bool(value.autoPlayed) };
      });
    }
    function result(value) {
      return attempt("result", function () {
        return { gameId: id(value.gameId), emptyPiles: list(value.emptyPiles).map(function (v, i) {
          return enumKey("CardNames", v, "result/emptyPiles/" + i);
        }), players: list(value.playerResults).map(function (player, index) {
          const where = "result/players/" + index;
          return attempt(where, function () {
            return { playerId: integer(player.playerId), rank: integer(player.rank), resignIndex: integer(player.resignIndex),
              resignationType: enumKey("ResignationTypes", player.resignationType, where + "/resignation", true),
              cards: frequencies(player.cardNames, where + "/cards"),
              score: { totalPoints: integer(player.score.totalPoints), usedTurns: integer(player.score.usedTurns),
                parts: list(player.score.parts).map(function (part, i) {
                  const path = where + "/score/" + i;
                  return attempt(path, function () {
                    return { card: enumKey("CardNames", part.cardName, path), points: integer(part.points), count: integer(part.frequency),
                      explanation: part.explanation ? logEntry(part.explanation, path + "/explanation", 1) : null };
                  });
                }) } };
          });
        }) };
      });
    }
    function cardRef(card, where) {
      if (!card) return null;
      return { id: Number.isSafeInteger(card.id) && card.id >= 0 ? card.id : null, card: enumKey("CardNames", card.cardName, where) };
    }
    function state(value) {
      if (!value) { warn("final-state-unavailable", "finalState"); return null; }
      return attempt("finalState", function () {
        const players = list(value.players).map(function (player, i) {
          const where = "finalState/players/" + i;
          return attempt(where, function () {
            return { index: integer(player.index), playerId: integer(player.playerId), name: text(player.name, 500),
              isMe: typeof player.isMe === "boolean" ? player.isMe : null,
              boughtProjects: list(player.boughtProjects || []).map(function (v, j) { return enumKey("CardNames", v, where + "/projects/" + j); }) };
          });
        });
        const zones = list(value.zones).map(function (zone, i) {
          if (!zone) return null;
          const where = "finalState/zones/" + i;
          return attempt(where, function () {
            const zoneClass = ZONE_CLASSES.find(function (name) { return env[name] && zone.constructor === env[name]; }) || null;
            const isDrawZone = zoneClass === "DrawZone";
            const hasPrimaryStacks = isDrawZone && Array.isArray(zone.primaryStacks);
            const stackSource = hasPrimaryStacks ? "primaryStacks" : "cardStacks";
            function exportStacks(raw, path) {
              return list(raw).map(function (stack, j) {
                return attempt(path + "/" + j, function () {
                  const knownCards = list(stack.cards).map(function (card, k) { return cardRef(card, path + "/" + j + "/" + k); });
                  const unknownCount = integer(stack.anonymousCards);
                  if (unknownCount < 0) throw new Error("negative-card-count");
                  return { cards: knownCards, unknownCount, count: knownCards.length + unknownCount,
                    displayCard: cardRef(stack.topCard || stack.stackCard, path + "/" + j + "/displayCard") };
                });
              });
            }
            // Native DrawZone holds the same deck in primaryStacks and
            // windowStacks. Adding all cardStacks would double the deck count.
            const stacks = exportStacks(hasPrimaryStacks ? zone.primaryStacks : zone.cardStacks, where + "/stacks");
            const windowStacks = isDrawZone && Array.isArray(zone.windowStacks) ?
              exportStacks(zone.windowStacks, where + "/windowStacks") : null;
            const contentsScope = zoneClass === "DiscardZone" ? "top-card-only" :
              isDrawZone && !hasPrimaryStacks ? "ambiguous-display-stacks" : "client-known-entries";
            if (isDrawZone && !hasPrimaryStacks) warn("draw-stack-roles-unavailable", where);
            const cardCount = contentsScope === "top-card-only" || contentsScope === "ambiguous-display-stacks" ||
              stacks.some(function (stack) { return stack.unavailable; }) ? null :
              stacks.reduce(function (count, stack) { return count + stack.count; }, 0);
            return { index: integer(zone.index), zoneClass,
              zoneTypeOrdinals: Array.from(env.ZoneNames || []).map(function (ctor, j) { return ctor === zone.constructor ? j : -1; }).filter(function (j) { return j >= 0; }),
              ownerIndex: zone.owner && Number.isSafeInteger(zone.owner.index) ? zone.owner.index : null,
              pile: enumKey("CardNames", zone.pileName, where + "/pile", true), createdBy: cardRef(zone.createdBy, where + "/createdBy"),
              attachedTrait: enumKey("CardNames", zone.attachedTrait, where + "/trait", true),
              isVisible: typeof zone.isVisible === "boolean" ? zone.isVisible : null,
              stackSource, contentsScope, cardCount, stacks, windowStacks };
          });
        }).filter(function (zone) { return zone !== null; });
        const cards = list(value.cards).map(function (card, i) {
          if (!card) return null;
          return attempt("finalState/cards/" + i, function () {
            return { ...cardRef(card, "finalState/cards/" + i), pile: enumKey("CardNames", card.pileName, "finalState/cards/" + i + "/pile", true),
              zoneIndex: card.zone && Number.isSafeInteger(card.zone.index) ? card.zone.index : null };
          });
        }).filter(function (card) { return card !== null; });
        const counters = list(value.counters || []).map(function (counter, i) {
          if (!counter) return null;
          const where = "finalState/counters/" + i;
          return attempt(where, function () {
            return { index: integer(counter.index), name: enumKey("CounterNames", counter.counterName, where + "/name"),
              ownerIndex: counter.owner && Number.isSafeInteger(counter.owner.index) ? counter.owner.index : null,
              zoneIndex: counter.associatedPile && Number.isSafeInteger(counter.associatedPile.index) ? counter.associatedPile.index : null,
              cardId: counter.associatedCard && Number.isSafeInteger(counter.associatedCard.id) ? counter.associatedCard.id : null,
              value: integer(counter.value), isVisible: typeof counter.isVisible === "boolean" ? counter.isVisible : null };
          });
        }).filter(function (counter) { return counter !== null; });
        for (const [i, name] of (value.cardNames || []).entries()) enumKey("CardNames", name, "finalState/cardNames/" + i);
        return { players, zones, cards, counters,
          activeTurn: value.activeTurn ? attempt("finalState/activeTurn", function () { return turn(value.activeTurn); }) : null,
          historicalSnapshot: false };
      });
    }
    function catalog() {
      const result = {};
      for (const key of Array.from(referencedCards).sort()) {
        result[key] = attempt("cardCatalog/" + key, function () {
          const card = env.CardNames[key];
          const translated = env.LANGUAGE && env.LANGUAGE.getCardName && env.LANGUAGE.getCardName[card];
          return { englishName: text(card.name, 500), localizedName: translated ? text(translated.singular, 500) : null,
            types: list(card.types || []).map(function (type, i) { return enumKey("Types", type, "cardCatalog/" + key + "/types/" + i); }),
            expansion: enumKey("Expansions", card.expansion, "cardCatalog/" + key + "/expansion", true),
            isKingdomPile: typeof card._isKingdomPile === "boolean" ? card._isKingdomPile : null, cost: card.cost ? cost(card.cost) : null };
        });
      }
      return result;
    }
    return { entry, result, state, catalog, warnings, warn };
  }

  function build(context, env, clientVersion) {
    // The caller must also verify visible loading UI and table eligibility.
    if (!context || !context.game || context.game.isRunning() !== false) return null;
    const game = context.game;
    const completed = game.metaGameModel && game.metaGameModel.gameResult;
    if (!completed) return null;
    const model = game.logModel;
    if (!model || !Array.isArray(model.entries) || model.entries.length === 0) return null;
    if (!env.CardNames || !env.LogEntryNames || !env.LogArgumentParsers) throw new Error("missing-catalog");
    const s = serializer(env);
    const entries = list(model.entries).map(function (v, i) { return s.entry(v, "entries/" + i); })
      .sort(function (a, b) { return (a.index === undefined ? Infinity : a.index) - (b.index === undefined ? Infinity : b.index); });
    const logs = entries.filter(function (entry) { return entry.kind === "log"; });
    const decisions = entries.filter(function (entry) { return entry.kind === "decision"; });
    const retainedIds = Array.from(new Set(logs.filter(function (entry) { return entry.name === "GAME_META_INFO"; }).flatMap(function (entry) {
      return entry.arguments.filter(function (arg) { return arg.type === "METAGAME_INFO" && arg.value && arg.value.gameId; }).map(function (arg) { return arg.value.gameId; });
    })));
    let replayRuleArchiveId = null;
    let replayDecisionIndex = null;
    let replaySettingPlayers = null;
    try {
      const instructions = context.replay && context.replay.getReplayInstructions();
      replayRuleArchiveId = instructions ? id(instructions.gameId) : null;
      replayDecisionIndex = instructions && Number.isSafeInteger(instructions.decisionIndex) ? instructions.decisionIndex : null;
      if (instructions && Array.isArray(instructions.playerList)) {
        replaySettingPlayers = list(instructions.playerList).map(function (player, seatIndex) {
          return { seatIndex, playerId: integer(player.id), name: text(player.name, 500) };
        });
      }
    } catch (_) { s.warn("replay-instructions-unavailable", "source"); }
    const resultGameId = id(completed.gameId);
    const displayedGameId = id(game.displayedGameId);
    const requestedArchiveId = id(context.requestedGameId);
    const requestedIdOccursInRecord = Boolean(requestedArchiveId && (retainedIds.includes(requestedArchiveId) || resultGameId === requestedArchiveId));
    const identityStatus = requestedIdOccursInRecord ? "requested-id-occurs-in-retained-record" :
      replayRuleArchiveId === requestedArchiveId ? "requested-id-is-current-replay-setting-only" : "unverified";
    // A current replay setting is not proof that the retained log came from it.
    // Archive loading may also create a copy with a different game number.
    if (!requestedIdOccursInRecord) s.warn("archive-origin-not-verified", "source");
    if (retainedIds.length > 1) s.warn("multiple-retained-game-ids", "source");
    const exportedResult = s.result(completed);
    const finalState = s.state(game.state);
    const cardCatalog = s.catalog();
    if (entries[0].index > 0) s.warn("initial-log-prefix-missing", "entries");
    if (entries.some(function (entry) { return entry.unavailable; })) s.warn("some-entries-unavailable", "entries");
    if (game.isRunning() !== false) return null;
    return {
      format: "dominion-replay-record/v1", exporterVersion: VERSION, createdAt: new Date().toISOString(), clientVersion: clientVersion || null,
      source: { site: "https://dominion.games/", requestedArchiveId, replayRuleArchiveId, replayDecisionIndex, replaySettingPlayers,
        retainedLogGameIds: retainedIds, resultGameId, displayedGameId,
        identity: { status: identityStatus, requestedIdOccursInRecord, archiveLoadWasObserved: false, copiedArchiveOriginalIdVerified: false } },
      summary: { entryCount: model.entries.length, structuredLogEntryCount: logs.length, decisionEntryCount: decisions.length,
        firstEntryIndex: entries[0].index == null ? null : entries[0].index, lastEntryIndex: entries[entries.length - 1].index == null ? null : entries[entries.length - 1].index,
        warningCount: s.warnings.length },
      entries, plainTextLog: logs.flatMap(function (entry) { return entry.textLines; }).join("\n"),
      result: exportedResult, finalState, cardCatalog, warnings: s.warnings,
      scope: { kind: "completed-game-record", collection: "manual-click", noGameplayRequests: true, noAutomaticGameLoading: true,
        clientVisibleDataOnly: true, omniscient: false, containsHistoricalBoardSnapshots: false, requiresReplayAdapter: true,
        excludes: ["account-credentials", "chat", "ratings", "card-preference-lists", "premove-entries"] }
    };
  }
  const api = { VERSION, ARGUMENT_TYPES, build, serializer };
  if (typeof window === "undefined" && typeof module === "object" && module.exports) module.exports = api;
  else root.DominionRecordExport = api;
})(typeof globalThis === "object" ? globalThis : this);
